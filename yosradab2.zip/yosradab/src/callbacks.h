#include <gtk/gtk.h>


void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_controle_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_date_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_enregister_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_check_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_done_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2back_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_backe_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
